package com.slotmachine;

import java.util.Random;

public class ActionChain {
    
    Handler chain;
    
    public static final int SUCCESS = 1;
    public static final int CHANCE = 2;
    public static final int LOSS = 3;
    
    Random generate;
    final int NUMHANDLER = 3;
    
    private int lastResult = 0;
    
    public ActionChain() {
        generate = new Random();
        buildChain();
    }
    
    private void buildChain() {
        chain = new NegativeHandler(
                    new ChanceHandler(
                        new PositiveHandler(null)));
    }
    
    public boolean process() {
        lastResult = generate.nextInt(NUMHANDLER) + 1;
        System.out.println("ActionChain: Result = " + lastResult);
        
        return chain.process(lastResult);
    }
    
    public int getLastResult() {
        return lastResult;
    }
}
