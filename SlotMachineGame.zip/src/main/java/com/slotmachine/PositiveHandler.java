package com.slotmachine;

public class PositiveHandler extends Handler {
    
    public PositiveHandler(Handler processor) {
        super(processor);
    }

    @Override
    public boolean process(Integer request) {
        if (request == ActionChain.SUCCESS) {
            System.out.println("PositiveHandler: WIN!");
            return true;
        } else {
            return super.process(request);
        }
    }
}
