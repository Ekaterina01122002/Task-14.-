package com.slotmachine;

public class Player {

    private final String name;
    private int count;      // количество игр
    private int number;     // количество монет

    // Накопление выигрыша до кэшаута
    private int pendingWin;

    // Серия побед подряд
    private int winStreak;

    public Player(String name, Integer number) {
        this.name = name;
        this.number = number == null ? 0 : number;
        this.count = 0;

        this.pendingWin = 0;
        this.winStreak = 0;
    }

    // Списание монеты за игру
    public boolean pay(Integer price) {
        int cost = price == null ? 0 : price;

        if (cost <= 0) {
            return true;
        }

        if (number >= cost) {
            number -= cost;
            count++;
            return true;
        }

        return false;
    }

    // Начисление монет (пополнение, награда, ручное добавление)
    public void addNumber(Integer add) {
        int value = add == null ? 0 : add;
        if (value <= 0) {
            return;
        }
        number += value;
    }

    // Регистрируем выигрыш (копим до кэшаута)
    public void registerWin(int payout) {
        if (payout <= 0) {
            winStreak++;
            return;
        }

        pendingWin += payout;
        winStreak++;
    }

    // Сброс серии и накопленного выигрыша (проигрыш / стоп)
    public void resetSeries() {
        pendingWin = 0;
        winStreak = 0;
    }

    // Забрать накопленное в баланс
    public int cashOut() {
        int gained = pendingWin;
        if (gained > 0) {
            number += gained;
        }

        resetSeries();
        return gained;
    }

    public Integer getCount() {
        return count;
    }

    public Integer getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public int getPendingWin() {
        return pendingWin;
    }

    public int getWinStreak() {
        return winStreak;
    }
}
