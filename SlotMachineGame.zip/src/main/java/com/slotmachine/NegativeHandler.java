package com.slotmachine;

public class NegativeHandler extends Handler {
    
    public NegativeHandler(Handler processor) {
        super(processor);
    }

    @Override
    public boolean process(Integer request) {
        if (request == ActionChain.LOSS) {
            System.out.println("NegativeHandler: LOSS!");
            return false;
        } else {
            return super.process(request);
        }
    }
}
