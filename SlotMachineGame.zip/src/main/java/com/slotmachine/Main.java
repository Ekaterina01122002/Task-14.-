package com.slotmachine;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/game.fxml"));
        Scene scene = new Scene(root);
        
        try {
            scene.getStylesheets().add(getClass().getResource("/game-styles.css").toExternalForm());
        } catch (Exception e) {
            System.out.println("CSS не найден");
        }
        
        primaryStage.setTitle("Fortune Slots");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
