package com.slotmachine;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class Controller {

    @FXML private ImageView view;
    @FXML private Label coinLabel;
    @FXML private Label gamesLabel;
    @FXML private Label hintLabel;
    @FXML private Label resultLabel;
    @FXML private VBox choicePanel;
    @FXML private Label winAmountLabel;
    @FXML private Button continueBtn;
    @FXML private Button cashOutBtn;

    private static final int WIN_PAYOUT = 1;

    ActionChain action = null;
    Player player1;

    private Image coinSpriteSheet;
    private Image bagOpeningSprite;
    private Image bagsImage;

    private final int COIN_COLUMNS = 4;
    private final int COIN_WIDTH = 400;
    private final int COIN_HEIGHT = 400;
    private final int COIN_FRAMES = 8;

    private final int BAG_WIDTH = 400;
    private final int BAG_HEIGHT = 800;

    private int currentCoinFrame = 0;
    private int lastResult = 0;
    private Timeline coinAnimation;
    private Timeline bagAnimation;
    private boolean isGameActive = false;

    @FXML
    public void initialize() {
        player1 = new Player("Player 1", 5);
        updateLabels();

        try {
            coinSpriteSheet = new Image(getClass().getResourceAsStream("/images/coin-sprite-sheet.png"));
            bagOpeningSprite = new Image(getClass().getResourceAsStream("/images/bag-opening-sprite.png"));
            bagsImage = new Image(getClass().getResourceAsStream("/images/мешочки.png"));

            if (coinSpriteSheet != null && !coinSpriteSheet.isError()) {
                showCoinFrame(0);
                startCoinAnimation();
                System.out.println("=== GAME STARTED ===");
                System.out.println("Balance: " + player1.getNumber() + " coins");
            } else {
                System.out.println("ERROR: Failed to load coin sprite");
            }

        } catch (Exception e) {
            System.out.println("ERROR loading images: " + e.getMessage());
            e.printStackTrace();
        }

        view.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            if (action == null || !isGameActive) {
                shakeAnimation(view);
                return;
            }

            isGameActive = false;
            handleBagClick();
        });

        if (hintLabel != null) {
            updateHint("Press 'START GAME' to begin");
        }
    }

    private void handleBagClick() {
        System.out.println("\n=== CLICK ON BAG ===");

        boolean continueGame = action.process();
        lastResult = action.getLastResult();

        String message;
        String color;

        if (lastResult == ActionChain.SUCCESS) {
            player1.registerWin(WIN_PAYOUT);

            message = "YOU WON!";
            color = "#2ECC71";

            System.out.println("WIN! +" + WIN_PAYOUT + " (pending)");
            System.out.println("Pending: " + player1.getPendingWin() + " | Streak: " + player1.getWinStreak());
        } else if (lastResult == ActionChain.CHANCE) {
            message = "LUCKY CHANCE!\nFree game!";
            color = "#FFA500";

            System.out.println("CHANCE! Free game");
            System.out.println("Pending: " + player1.getPendingWin() + " | Streak: " + player1.getWinStreak());
        } else {
            player1.resetSeries();

            message = "YOU LOST!";
            color = "#E74C3C";

            System.out.println("LOSS! Series burned");
        }

        System.out.println("Balance: " + player1.getNumber());

        playBagOpeningAnimation(message, color, lastResult, continueGame);
    }

    private void showCoinFrame(int frameIndex) {
        if (coinSpriteSheet == null || coinSpriteSheet.isError()) {
            return;
        }

        int column = frameIndex % COIN_COLUMNS;
        int row = frameIndex / COIN_COLUMNS;

        view.setImage(coinSpriteSheet);
        view.setViewport(
                new Rectangle2D(
                        column * COIN_WIDTH,
                        row * COIN_HEIGHT,
                        COIN_WIDTH,
                        COIN_HEIGHT
                )
        );

        currentCoinFrame = frameIndex;
    }

    private void startCoinAnimation() {
        if (coinSpriteSheet == null || coinSpriteSheet.isError()) {
            return;
        }

        coinAnimation = new Timeline(
                new KeyFrame(Duration.millis(100), event -> {
                    currentCoinFrame = (currentCoinFrame + 1) % COIN_FRAMES;
                    showCoinFrame(currentCoinFrame);
                })
        );

        coinAnimation.setCycleCount(Timeline.INDEFINITE);
        coinAnimation.play();
    }

    private void stopCoinAnimation() {
        if (coinAnimation != null) {
            coinAnimation.stop();
        }
    }

    private void showBagFrame(int frameIndex) {
        if (bagOpeningSprite == null || bagOpeningSprite.isError()) {
            return;
        }

        view.setImage(bagOpeningSprite);
        view.setViewport(new Rectangle2D(frameIndex * BAG_WIDTH, 0, BAG_WIDTH, BAG_HEIGHT));
    }

    private void playBagOpeningAnimation(
            String message,
            String color,
            int result,
            boolean continueGame
    ) {
        if (bagOpeningSprite == null || bagOpeningSprite.isError()) {
            return;
        }

        stopCoinAnimation();
        hideResultLabel();
        hideChoicePanel();

        final int[] currentFrame = {0};

        if (bagAnimation != null) {
            bagAnimation.stop();
        }

        bagAnimation = new Timeline(
                new KeyFrame(Duration.millis(250), event -> {
                    showBagFrame(currentFrame[0]);
                    currentFrame[0]++;

                    if (currentFrame[0] >= 5) {
                        bagAnimation.stop();

                        showResultText(message, color);

                        PauseTransition pause = new PauseTransition(Duration.millis(2000));
                        pause.setOnFinished(e -> {
                            hideResultLabel();

                            if (result == ActionChain.SUCCESS) {
                                showWinChoice();
                                return;
                            }

                            if (result == ActionChain.CHANCE) {
                                System.out.println("\n=== FREE GAME (CHANCE) ===");
                                System.out.println("Coin NOT charged");
                                System.out.println("Balance: " + player1.getNumber());

                                action = new ActionChain();
                                showThreeBags();
                                return;
                            }

                            showLossChoice();
                        });
                        pause.play();
                    }
                })
        );

        bagAnimation.setCycleCount(5);
        bagAnimation.play();
    }

    private void showResultText(String text, String color) {
        if (resultLabel == null) {
            return;
        }

        resultLabel.setText(text);
        resultLabel.setStyle(
                "-fx-text-fill: white; -fx-font-size: 50px; -fx-font-weight: bold; " +
                        "-fx-background-color: " + color + "; -fx-padding: 30 50; " +
                        "-fx-background-radius: 20px; -fx-border-color: white; " +
                        "-fx-border-width: 5px; -fx-border-radius: 20px; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.8), 20, 0.5, 0, 10); " +
                        "-fx-text-alignment: center;"
        );

        resultLabel.setVisible(true);
        resultLabel.setOpacity(0);
        resultLabel.setScaleX(0.5);
        resultLabel.setScaleY(0.5);

        FadeTransition fade = new FadeTransition(Duration.millis(300), resultLabel);
        fade.setToValue(1.0);

        ScaleTransition scale = new ScaleTransition(Duration.millis(300), resultLabel);
        scale.setToX(1.0);
        scale.setToY(1.0);

        ParallelTransition parallel = new ParallelTransition(fade, scale);
        parallel.play();
    }

    private void hideResultLabel() {
        if (resultLabel == null) {
            return;
        }

        FadeTransition fade = new FadeTransition(Duration.millis(200), resultLabel);
        fade.setToValue(0.0);
        fade.setOnFinished(e -> resultLabel.setVisible(false));
        fade.play();
    }

    private void showWinChoice() {
        if (choicePanel == null) {
            return;
        }

        int pending = player1.getPendingWin();
        int streak = player1.getWinStreak();

        winAmountLabel.setText("Pending: +" + pending + " coin(s)\nStreak: " + streak);
        winAmountLabel.setStyle("-fx-text-fill: white; -fx-font-size: 22px;");

        Label titleLabel = (Label) choicePanel.getChildren().get(0);
        titleLabel.setText("YOU WON!");
        titleLabel.setStyle(
                "-fx-text-fill: #2ECC71; -fx-font-size: 40px; -fx-font-weight: bold;"
        );

        continueBtn.setText("▶ PLAY MORE");
        cashOutBtn.setText("💰 CASH OUT");

        choicePanel.setVisible(true);
        choicePanel.setOpacity(0);

        FadeTransition fade = new FadeTransition(Duration.millis(400), choicePanel);
        fade.setToValue(1.0);
        fade.play();
    }

    private void showLossChoice() {
        if (choicePanel == null) {
            return;
        }

        winAmountLabel.setText("");

        Label titleLabel = (Label) choicePanel.getChildren().get(0);
        titleLabel.setText("YOU LOST!");
        titleLabel.setStyle(
                "-fx-text-fill: #E74C3C; -fx-font-size: 40px; -fx-font-weight: bold;"
        );

        continueBtn.setText("🎲 TRY AGAIN");
        cashOutBtn.setText("❌ STOP");

        choicePanel.setVisible(true);
        choicePanel.setOpacity(0);

        FadeTransition fade = new FadeTransition(Duration.millis(400), choicePanel);
        fade.setToValue(1.0);
        fade.play();
    }

    private void hideChoicePanel() {
        if (choicePanel == null) {
            return;
        }
        choicePanel.setVisible(false);
    }

    @FXML
    public void onContinue(ActionEvent event) {
        hideChoicePanel();

        if (!init()) {
            action = null;
            loadCoinSprite();
            updateHint("No coins! Add more");
            return;
        }

        updateLabels();
        action = new ActionChain();
        showThreeBags();
    }

    @FXML
    public void onCashOut(ActionEvent event) {
        hideChoicePanel();

        if (lastResult == ActionChain.SUCCESS) {
            int gained = player1.cashOut();

            System.out.println("\n=== CASH OUT ===");
            System.out.println("Received: +" + gained + " coin(s)");
            System.out.println("Balance: " + player1.getNumber());

            updateLabelsWithAnimation();
            updateHint("Win cashed out! Press 'START GAME'");
        } else {
            // STOP после проигрыша: просто сбросим всё, чтобы не тянулось дальше
            player1.resetSeries();

            updateLabelsWithAnimation();
            updateHint("Game stopped. Press 'START GAME'");
        }

        action = null;
        loadCoinSprite();
    }

    private void showThreeBags() {
        if (bagsImage == null || bagsImage.isError()) {
            return;
        }

        view.setViewport(null);
        view.setImage(bagsImage);

        FadeTransition fade = new FadeTransition(Duration.millis(400), view);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();

        isGameActive = true;

        if (hintLabel != null) {
            updateHint("Click to choose a bag!");
        }
    }

    private void loadCoinSprite() {
        if (coinSpriteSheet == null || coinSpriteSheet.isError()) {
            return;
        }

        FadeTransition fade = new FadeTransition(Duration.millis(500), view);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.setOnFinished(e -> startCoinAnimation());

        showCoinFrame(0);
        fade.play();
    }

    @FXML
    public void onPay(ActionEvent actionEvent) {
        player1.addNumber(1);
        updateLabelsWithAnimation();

        System.out.println("\n=== COIN ADDED ===");
        System.out.println("Balance: " + player1.getNumber());

        FadeTransition fade = new FadeTransition(Duration.millis(300), coinLabel);
        fade.setFromValue(0.3);
        fade.setToValue(1.0);
        fade.play();

        ScaleTransition scale = new ScaleTransition(Duration.millis(300), coinLabel);
        scale.setFromX(1.3);
        scale.setFromY(1.3);
        scale.setToX(1.0);
        scale.setToY(1.0);
        scale.play();

        if (hintLabel != null) {
            updateHint("+1 coin! Balance: " + player1.getNumber());
        }
    }

    @FXML
    public void onStart(ActionEvent actionEvent) {
        if (!init()) {
            return;
        }

        stopCoinAnimation();

        PauseTransition pause = new PauseTransition(Duration.millis(300));
        pause.setOnFinished(e -> {
            action = new ActionChain();
            showThreeBags();
        });
        pause.play();
    }

    private boolean init() {
        if (player1.getNumber() < 1) {
            if (hintLabel != null) {
                updateHint("Not enough coins! Add more");
            }
            shakeAnimation(coinLabel);
            return false;
        }

        player1.pay(1);
        updateLabels();

        System.out.println("\n=== GAME START ===");
        System.out.println("Charged: -1 coin");
        System.out.println("Balance: " + player1.getNumber());
        System.out.println("Games: " + player1.getCount());

        return true;
    }

    private void updateLabels() {
        coinLabel.setText(String.valueOf(player1.getNumber()));
        gamesLabel.setText(String.valueOf(player1.getCount()));
    }

    private void updateLabelsWithAnimation() {
        updateLabels();

        FadeTransition fade1 = new FadeTransition(Duration.millis(200), coinLabel);
        fade1.setFromValue(0.5);
        fade1.setToValue(1.0);
        fade1.play();

        FadeTransition fade2 = new FadeTransition(Duration.millis(200), gamesLabel);
        fade2.setFromValue(0.5);
        fade2.setToValue(1.0);
        fade2.play();
    }

    private void updateHint(String text) {
        if (hintLabel == null) {
            return;
        }

        hintLabel.setText(text);

        FadeTransition fade = new FadeTransition(Duration.millis(400), hintLabel);
        fade.setFromValue(0.3);
        fade.setToValue(1.0);
        fade.play();
    }

    private void shakeAnimation(javafx.scene.Node node) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(100), node);
        translate.setFromX(0);
        translate.setByX(10);
        translate.setCycleCount(4);
        translate.setAutoReverse(true);
        translate.play();
    }
}
