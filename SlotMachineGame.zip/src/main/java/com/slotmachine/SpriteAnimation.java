package com.slotmachine;

import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.util.Duration;

/**
 * Класс для работы со спрайтами (sprite sheets)
 * Позволяет загружать спрайт-лист и отображать отдельные кадры
 */
public class SpriteAnimation {
    
    private ImageView imageView;
    private Image spriteSheet;
    private int columns;
    private int rows;
    private int frameWidth;
    private int frameHeight;
    private int totalFrames;
    private int currentFrame;
    private Timeline animation;
    
    /**
     * Конструктор для создания спрайт-анимации
     * 
     * @param spriteSheetPath путь к спрайт-листу
     * @param columns количество колонок в спрайт-листе
     * @param rows количество строк в спрайт-листе
     * @param frameWidth ширина одного кадра
     * @param frameHeight высота одного кадра
     */
    public SpriteAnimation(String spriteSheetPath, int columns, int rows, int frameWidth, int frameHeight) {
        this.spriteSheet = new Image(getClass().getResourceAsStream(spriteSheetPath));
        this.columns = columns;
        this.rows = rows;
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
        this.totalFrames = columns * rows;
        this.currentFrame = 0;
        
        this.imageView = new ImageView(spriteSheet);
        updateFrame(0);
    }
    
    /**
     * Обновляет отображаемый кадр
     * @param frameIndex индекс кадра (0 - первый кадр)
     */
    public void updateFrame(int frameIndex) {
        if (frameIndex < 0 || frameIndex >= totalFrames) {
            frameIndex = 0;
        }
        
        this.currentFrame = frameIndex;
        
        // Вычисляем позицию кадра в спрайт-листе
        int column = frameIndex % columns;
        int row = frameIndex / columns;
        
        int x = column * frameWidth;
        int y = row * frameHeight;
        
        // Устанавливаем viewport для отображения только нужного кадра
        imageView.setViewport(new Rectangle2D(x, y, frameWidth, frameHeight));
    }
    
    /**
     * Запускает анимацию спрайтов
     * @param duration длительность одного кадра в миллисекундах
     * @param loop зациклить анимацию или нет
     */
    public void play(double duration, boolean loop) {
        if (animation != null) {
            animation.stop();
        }
        
        animation = new Timeline(
            new KeyFrame(Duration.millis(duration), event -> {
                currentFrame++;
                if (currentFrame >= totalFrames) {
                    if (loop) {
                        currentFrame = 0;
                    } else {
                        animation.stop();
                        return;
                    }
                }
                updateFrame(currentFrame);
            })
        );
        
        animation.setCycleCount(loop ? Timeline.INDEFINITE : totalFrames);
        animation.play();
    }
    
    /**
     * Останавливает анимацию
     */
    public void stop() {
        if (animation != null) {
            animation.stop();
        }
    }
    
    /**
     * Возвращает ImageView со спрайтом
     */
    public ImageView getImageView() {
        return imageView;
    }
    
    /**
     * Устанавливает размер отображаемого изображения
     */
    public void setSize(double width, double height) {
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        imageView.setPreserveRatio(true);
    }
    
    /**
     * Возвращает текущий кадр
     */
    public int getCurrentFrame() {
        return currentFrame;
    }
    
    /**
     * Возвращает общее количество кадров
     */
    public int getTotalFrames() {
        return totalFrames;
    }
}
