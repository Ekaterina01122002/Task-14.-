package com.slotmachine;

public class ChanceHandler extends Handler {

    public ChanceHandler(Handler processor) {
        super(processor);
    }

    @Override
    public boolean process(Integer request) {
        if (request == ActionChain.CHANCE) {
            System.out.println("ChanceHandler: CHANCE! Free game!");
            return true;
        }
        return super.process(request);
    }
}
